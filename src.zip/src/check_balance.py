#!/usr/bin/env python3
"""
Verificar saldo das carteiras
"""
import os
from dotenv import load_dotenv
from circle.web3 import developer_controlled_wallets
from circle.web3 import utils

load_dotenv()

WALLETS = {
    "ETH Sepolia": "2ed682d1-29d3-5398-a7d2-4c9f8f56f54d",
    "Arc Testnet": "12d2ca1e-d1a0-5d46-93e8-8d76c6aba102"
}

def check_balances():
    print("=" * 70)
    print("Verificador de Saldo - Carteiras")
    print("=" * 70 + "\n")
    
    api_key = os.getenv("CIRCLE_API_KEY")
    entity_secret = os.getenv("CIRCLE_ENTITY_SECRET")
    
    if not api_key or not entity_secret:
        print("❌ Credenciais não configuradas!")
        return
    
    try:
        client = utils.init_developer_controlled_wallets_client(
            api_key=api_key,
            entity_secret=entity_secret
        )
        
        wallets_api = developer_controlled_wallets.WalletsApi(client)
        
        for name, wallet_id in WALLETS.items():
            print(f"📊 {name}")
            print(f"   Wallet ID: {wallet_id}\n")
            
            try:
                balance_response = wallets_api.list_wallet_balance(id=wallet_id)
                
                if balance_response.data and balance_response.data.token_balances:
                    print(f"   Tokens encontrados: {len(balance_response.data.token_balances)}\n")
                    
                    for token_balance in balance_response.data.token_balances:
                        token = token_balance.token
                        amount = token_balance.amount
                        print(f"   - {token.symbol} ({token.name})")
                        print(f"     Balance: {amount}")
                        print(f"     Blockchain: {token.blockchain}\n")
                else:
                    print("   ⚠️  Nenhum token encontrado\n")
            except Exception as e:
                print(f"   ❌ Erro: {str(e)}\n")
            
            print("-" * 70 + "\n")
        
    except Exception as e:
        print(f"❌ ERRO: {str(e)}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    check_balances()
