#!/usr/bin/env python3
"""
Script para criar 1 carteira Arc Testnet
Execute este SEGUNDO
"""
import os
import time
from dotenv import load_dotenv
from circle.web3 import developer_controlled_wallets
from circle.web3 import utils

load_dotenv()

def create_arc_testnet_wallet():
    print("=" * 70)
    print("Criador de Carteira Arc Testnet")
    print("=" * 70)
    
    api_key = os.getenv("CIRCLE_API_KEY")
    entity_secret = os.getenv("CIRCLE_ENTITY_SECRET")
    
    if not api_key or not entity_secret:
        print("\n❌ ERRO: Credenciais não configuradas!")
        return
    
    try:
        client = utils.init_developer_controlled_wallets_client(
            api_key=api_key,
            entity_secret=entity_secret
        )
        
        wallet_sets_api = developer_controlled_wallets.WalletSetsApi(client)
        wallets_api = developer_controlled_wallets.WalletsApi(client)
        
        print("\n✓ Cliente inicializado\n")
        
        # Criar novo Wallet Set
        print("CRIANDO WALLET SET...")
        wallet_set_request = developer_controlled_wallets.CreateWalletSetRequest.from_dict({
            "name": "Arc Testnet Wallet"
        })
        
        wallet_set_response = wallet_sets_api.create_wallet_set(
            create_wallet_set_request=wallet_set_request
        )
        
        wallet_set_id = wallet_set_response.data.wallet_set.actual_instance.id
        print(f"✓ Wallet Set criado: {wallet_set_id}\n")
        
        # Criar carteira Arc Testnet
        print("CRIANDO CARTEIRA ARC TESTNET...")
        time.sleep(2)
        
        arc_request = developer_controlled_wallets.CreateWalletRequest.from_dict({
            "walletSetId": wallet_set_id,
            "blockchains": ["ARC-TESTNET"],
            "count": 1
        })
        
        arc_response = wallets_api.create_wallet(
            create_wallet_request=arc_request
        )
        
        arc_wallet = arc_response.data.wallets[0]
        arc_wallet_id = arc_wallet.actual_instance.id
        arc_address = arc_wallet.actual_instance.address
        
        print(f"\n{'='*70}")
        print("✅ CARTEIRA ARC TESTNET CRIADA COM SUCESSO!")
        print(f"{'='*70}")
        print(f"\n📝 Wallet ID: {arc_wallet_id}")
        print(f"📝 Address: {arc_address}")
        print(f"📝 Blockchain: ARC-TESTNET\n")
        print(f"{'='*70}\n")
        
    except Exception as e:
        print(f"\n❌ ERRO: {str(e)}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    create_arc_testnet_wallet()
