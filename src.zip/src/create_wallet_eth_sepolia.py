#!/usr/bin/env python3
"""
Script para criar 1 carteira ETH Sepolia
Execute este PRIMEIRO
"""
import os
import time
from dotenv import load_dotenv
from circle.web3 import developer_controlled_wallets
from circle.web3 import utils

load_dotenv()

def create_eth_sepolia_wallet():
    print("=" * 70)
    print("Criador de Carteira ETH Sepolia")
    print("=" * 70)
    
    api_key = os.getenv("CIRCLE_API_KEY")
    entity_secret = os.getenv("CIRCLE_ENTITY_SECRET")
    
    if not api_key or not entity_secret:
        print("\n❌ ERRO: Credenciais não configuradas!")
        return
    
    try:
        client = utils.init_developer_controlled_wallets_client(
            api_key=api_key,
            entity_secret=entity_secret
        )
        
        wallet_sets_api = developer_controlled_wallets.WalletSetsApi(client)
        wallets_api = developer_controlled_wallets.WalletsApi(client)
        
        print("\n✓ Cliente inicializado\n")
        
        # Criar Wallet Set
        print("CRIANDO WALLET SET...")
        wallet_set_request = developer_controlled_wallets.CreateWalletSetRequest.from_dict({
            "name": "ETH Sepolia Wallet"
        })
        
        wallet_set_response = wallet_sets_api.create_wallet_set(
            create_wallet_set_request=wallet_set_request
        )
        
        wallet_set_id = wallet_set_response.data.wallet_set.actual_instance.id
        print(f"✓ Wallet Set criado: {wallet_set_id}\n")
        
        # Criar carteira ETH Sepolia
        print("CRIANDO CARTEIRA ETH SEPOLIA...")
        time.sleep(2)
        
        eth_request = developer_controlled_wallets.CreateWalletRequest.from_dict({
            "walletSetId": wallet_set_id,
            "blockchains": ["ETH-SEPOLIA"],
            "count": 1
        })
        
        eth_response = wallets_api.create_wallet(
            create_wallet_request=eth_request
        )
        
        eth_wallet = eth_response.data.wallets[0]
        eth_wallet_id = eth_wallet.actual_instance.id
        eth_address = eth_wallet.actual_instance.address
        
        print(f"\n{'='*70}")
        print("✅ CARTEIRA ETH SEPOLIA CRIADA COM SUCESSO!")
        print(f"{'='*70}")
        print(f"\n📝 Wallet ID: {eth_wallet_id}")
        print(f"📝 Address: {eth_address}")
        print(f"📝 Blockchain: ETH-SEPOLIA\n")
        print(f"{'='*70}\n")
        
    except Exception as e:
        print(f"\n❌ ERRO: {str(e)}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    create_eth_sepolia_wallet()
