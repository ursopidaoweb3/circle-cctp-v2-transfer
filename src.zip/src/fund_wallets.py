#!/usr/bin/env python3
"""
Instruções para fazer faucet e adicionar USDC às carteiras
"""

print("""
============================================================
Como Adicionar Fundos às Novas Carteiras
============================================================

✅ Carteiras Criadas:

1️⃣  ETH Sepolia
   - Wallet ID: 2ed682d1-29d3-5398-a7d2-4c9f8f56f54d
   - Address: 0x18ef55f6224e41bd10e20077db5547500ff95fb3

2️⃣  Arc Testnet
   - Wallet ID: 12d2ca1e-d1a0-5d46-93e8-8d76c6aba102
   - Address: 0xb9a4522ced507631905e6540d7c9d4ea2d4ab973

============================================================
Passo 1: Adicionar ETH Sepolia (para pagar gas)
============================================================

Acesse: https://www.alchemy.com/faucets/ethereum-sepolia

1. Cole o address: 0x18ef55f6224e41bd10e20077db5547500ff95fb3
2. Clique em "Send"
3. Aguarde receber ~0.5 ETH Sepolia

============================================================
Passo 2: Adicionar USDC (ETH Sepolia)
============================================================

Acesse: https://faucet.circle.com/

1. Selecione "Ethereum - Sepolia" como blockchain
2. Cole o address: 0x18ef55f6224e41bd10e20077db5547500ff95fb3
3. Clique em "Get USDC"
4. Aguarde receber ~100 USDC

⏳ Pode levar alguns minutos para confirmar na blockchain

============================================================
Passo 3: Pronto!
============================================================

Após receber os fundos, execute:

  python src/cctp_transfer.py

O script irá:
✅ Buscar USDC automaticamente
✅ Transferir 5.00 USDC para Arc Testnet
✅ Monitorar até conclusão

============================================================
Dúvidas?
============================================================

- Verifique seu address no block explorer:
  https://sepolia.etherscan.io/address/0x18ef55f6224e41bd10e20077db5547500ff95fb3

- Consulte balances com: python src/check_balance.py

============================================================
""")
