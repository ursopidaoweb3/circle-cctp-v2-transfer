#!/usr/bin/env python3
import os
import time
import requests
from dotenv import load_dotenv
from circle.web3 import developer_controlled_wallets, utils

load_dotenv()

SOURCE_WALLET_ID = "2ed682d1-29d3-5398-a7d2-4c9f8f56f54d"
DESTINATION_WALLET_ID = "12d2ca1e-d1a0-5d46-93e8-8d76c6aba102"

SOURCE_BLOCKCHAIN = "ETH-SEPOLIA"
DESTINATION_BLOCKCHAIN = "ARC-TESTNET"
DESTINATION_ADDRESS = "0xb9a4522ced507631905e6540d7c9d4ea2d4ab973"

# CCTP V2 Testnet Contract Addresses (OFFICIAL)
TOKEN_MESSENGER_ADDRESS = "0x8fe6b999dc680ccfdd5bf7eb0974218be2542daa"  # Sepolia V2
MESSAGE_TRANSMITTER_ADDRESS = "0xe737e5cebeeba77efe34d4aa090756590b1ce275"  # Arc V2
USDC_ADDRESS = "0x1c7d4b196cb0c7b01d743fbc6116a902379c7238"  # Sepolia USDC

AMOUNT = "5000000"  # 5 USDC
DESTINATION_DOMAIN = 26  # Arc Testnet
MIN_FINALITY_THRESHOLD = 0  # Fast transfer

def address_to_bytes32(address):
    address = address.replace("0x", "").lower()
    return "0x" + address.zfill(64)

def approve_usdc(wallet_id, blockchain, amount, usdc_address):
    request = developer_controlled_wallets.CreateContractExecutionTransactionForDeveloperRequest.from_dict({
        "walletId": wallet_id,
        "blockchain": blockchain,
        "contractAddress": usdc_address,
        "abiFunctionSignature": "approve(address,uint256)",
        "abiParameters": [TOKEN_MESSENGER_ADDRESS, amount],
        "feeLevel": "MEDIUM"
    })
    
    response = developer_controlled_wallets.TransactionsApi(
        utils.init_developer_controlled_wallets_client(
            api_key=os.getenv("CIRCLE_API_KEY"),
            entity_secret=os.getenv("CIRCLE_ENTITY_SECRET")
        )
    ).create_developer_transaction_contract_execution(
        create_contract_execution_transaction_for_developer_request=request
    )
    return response

def deposit_for_burn(wallet_id, blockchain, amount, destination_domain, mint_recipient, usdc_address):
    # CCTP V2 depositForBurn - 7 parameters (official signature)
    destination_caller = "0x0000000000000000000000000000000000000000000000000000000000000000"
    max_fee = "500"  # 0.0005 USDC - minimum fee required by Circle
    request = developer_controlled_wallets.CreateContractExecutionTransactionForDeveloperRequest.from_dict({
        "walletId": wallet_id,
        "blockchain": blockchain,
        "contractAddress": TOKEN_MESSENGER_ADDRESS,
        "abiFunctionSignature": "depositForBurn(uint256,uint32,bytes32,address,bytes32,uint256,uint32)",
        "abiParameters": [
            str(amount), 
            destination_domain, 
            mint_recipient, 
            usdc_address, 
            destination_caller, 
            max_fee, 
            MIN_FINALITY_THRESHOLD
        ],
        "feeLevel": "MEDIUM"
    })
    
    response = developer_controlled_wallets.TransactionsApi(
        utils.init_developer_controlled_wallets_client(
            api_key=os.getenv("CIRCLE_API_KEY"),
            entity_secret=os.getenv("CIRCLE_ENTITY_SECRET")
        )
    ).create_developer_transaction_contract_execution(
        create_contract_execution_transaction_for_developer_request=request
    )
    return response

def receive_message(wallet_id, blockchain, message, attestation):
    # Message and attestation must be hex strings with 0x prefix
    if message and not message.startswith('0x'):
        message = '0x' + message
    if attestation and not attestation.startswith('0x'):
        attestation = '0x' + attestation
    
    request = developer_controlled_wallets.CreateContractExecutionTransactionForDeveloperRequest.from_dict({
        "walletId": wallet_id,
        "blockchain": blockchain,
        "contractAddress": MESSAGE_TRANSMITTER_ADDRESS,
        "abiFunctionSignature": "receiveMessage(bytes,bytes)",
        "abiParameters": [message, attestation],
        "feeLevel": "MEDIUM"
    })
    
    response = developer_controlled_wallets.TransactionsApi(
        utils.init_developer_controlled_wallets_client(
            api_key=os.getenv("CIRCLE_API_KEY"),
            entity_secret=os.getenv("CIRCLE_ENTITY_SECRET")
        )
    ).create_developer_transaction_contract_execution(
        create_contract_execution_transaction_for_developer_request=request
    )
    return response

def poll_transaction(tx_id, blockchain):
    client = utils.init_developer_controlled_wallets_client(
        api_key=os.getenv("CIRCLE_API_KEY"),
        entity_secret=os.getenv("CIRCLE_ENTITY_SECRET")
    )
    transactions_api = developer_controlled_wallets.TransactionsApi(client)
    
    for _ in range(120):
        response = transactions_api.get_transaction(id=tx_id)
        state = response.data.transaction.state.value if hasattr(response.data.transaction.state, 'value') else str(response.data.transaction.state)
        
        if state in ["CONFIRMED", "COMPLETE"]:
            return response.data.transaction
        if state == "FAILED":
            error_reason = response.data.transaction.error_reason or "unknown"
            error_details = response.data.transaction.error_details or ""
            raise Exception(f"{error_reason}: {error_details}")
        
        time.sleep(1)
    
    raise Exception("Timeout")

def poll_attestation(burn_hash, max_retries=60):
    SOURCE_DOMAIN_ID = 0  # Ethereum Sepolia
    url = f"https://iris-api-sandbox.circle.com/v2/messages/{SOURCE_DOMAIN_ID}"
    
    for attempt in range(max_retries):
        try:
            response = requests.get(url, params={"transactionHash": burn_hash}, timeout=10)
            
            if response.status_code == 200:
                data = response.json()
                messages = data.get("messages", [])
                
                if messages:
                    msg = messages[0]
                    attestation = msg.get("attestation")
                    status = msg.get("status", "unknown")
                    
                    if attestation and attestation != "PENDING" and status == "complete":
                        elapsed = attempt * 5
                        print(f"  ✅ Attestation received in {elapsed}s!")
                        message = msg.get("message")
                        return message, attestation
                    elif attempt % 12 == 0:
                        print(f"  Waiting... status={status} ({attempt*5}s)")
            elif response.status_code == 404:
                if attempt % 12 == 0:
                    print(f"  Searching... ({attempt*5}s)")
        except Exception as e:
            if attempt % 20 == 0:
                print(f"  Retrying... ({attempt*5}s)")
        
        time.sleep(5)
    
    raise Exception("Attestation timeout after 5 minutes")

print("\n" + "="*70)
print("🔄 CCTP V2 Transfer: ETH Sepolia → Arc Testnet")
print("="*70)
print(f"5 USDC → {DESTINATION_ADDRESS}")
print("="*70 + "\n")

try:
    print("1️⃣  Approve")
    approve_tx = approve_usdc(SOURCE_WALLET_ID, SOURCE_BLOCKCHAIN, AMOUNT, USDC_ADDRESS)
    approve_tx_id = approve_tx.data.id
    approve_result = poll_transaction(approve_tx_id, SOURCE_BLOCKCHAIN)
    approve_hash = approve_result.tx_hash
    print(f"✅\n")

    print("2️⃣  Burn")
    mint_recipient = address_to_bytes32(DESTINATION_ADDRESS)
    burn_tx = deposit_for_burn(SOURCE_WALLET_ID, SOURCE_BLOCKCHAIN, AMOUNT, DESTINATION_DOMAIN, mint_recipient, USDC_ADDRESS)
    burn_tx_id = burn_tx.data.id
    burn_result = poll_transaction(burn_tx_id, SOURCE_BLOCKCHAIN)
    burn_hash = burn_result.tx_hash
    print(f"✅\n")

    print("3️⃣  Attestation")
    message, attestation = poll_attestation(burn_hash)
    print(f"✅\n")

    print("4️⃣  Mint")
    mint_tx = receive_message(DESTINATION_WALLET_ID, DESTINATION_BLOCKCHAIN, message, attestation)
    mint_tx_id = mint_tx.data.id
    mint_result = poll_transaction(mint_tx_id, DESTINATION_BLOCKCHAIN)
    mint_hash = mint_result.tx_hash
    print(f"✅\n")

    print("="*70)
    print("✅ SUCCESS!")
    print("="*70)
    print(f"\n📋 TRANSACTION LINKS:\n")
    print(f"Approve USDC:")
    print(f"  {approve_hash}")
    print(f"  https://sepolia.etherscan.io/tx/{approve_hash}\n")
    print(f"Burn USDC:")
    print(f"  {burn_hash}")
    print(f"  https://sepolia.etherscan.io/tx/{burn_hash}\n")
    print(f"Mint USDC:")
    print(f"  {mint_hash}")
    print(f"  https://sepolia-explorer.arbitrum.io/tx/{mint_hash}\n")
    print("="*70)

except Exception as e:
    print(f"\n❌ {str(e)}")
    exit(1)
