import os
import sys

print("=" * 70)
print("CCTP Transfer Script - Verificação de Configuração")
print("=" * 70)

print("\n✓ Python instalado com sucesso")
print(f"  Versão: {sys.version}")

try:
    import dotenv
    print("\n✓ python-dotenv instalado")
except ImportError:
    print("\n❌ python-dotenv não encontrado")
    print("   Execute: pip install python-dotenv")

try:
    from circle.web3 import developer_controlled_wallets
    from circle.web3 import utils
    print("✓ circle-developer-controlled-wallets instalado")
except ImportError:
    print("\n❌ circle-developer-controlled-wallets não encontrado")
    print("   Execute: pip install circle-developer-controlled-wallets")

print("\n" + "=" * 70)
print("Verificação de Secrets")
print("=" * 70)

api_key = os.getenv("CIRCLE_API_KEY")
entity_secret = os.getenv("CIRCLE_ENTITY_SECRET")

if api_key:
    print(f"\n✓ CIRCLE_API_KEY configurado ({len(api_key)} caracteres)")
else:
    print("\n⚠️  CIRCLE_API_KEY não configurado")
    print("   Configure este secret no Replit ou no arquivo .env")

if entity_secret:
    print(f"✓ CIRCLE_ENTITY_SECRET configurado ({len(entity_secret)} caracteres)")
else:
    print("⚠️  CIRCLE_ENTITY_SECRET não configurado")
    print("   Configure este secret no Replit ou no arquivo .env")

print("\n" + "=" * 70)
print("Como Executar o Script de Transferência CCTP")
print("=" * 70)

if api_key and entity_secret:
    print("\n✓ Tudo configurado! Execute o script:")
    print("\n   python src/cctp_transfer.py\n")
else:
    print("\n⚠️  Antes de executar o script, configure os secrets:")
    print("\n1. No Replit:")
    print("   - Vá para a aba 'Secrets'")
    print("   - Adicione CIRCLE_API_KEY e CIRCLE_ENTITY_SECRET")
    print("\n2. Ou crie um arquivo .env:")
    print("   - Copie .env.example para .env")
    print("   - Adicione suas credenciais")
    print("\n3. Então execute:")
    print("   python src/cctp_transfer.py\n")

print("=" * 70)
print("Documentação Completa")
print("=" * 70)
print("\nLeia o README.md para instruções detalhadas")
print("=" * 70 + "\n")
